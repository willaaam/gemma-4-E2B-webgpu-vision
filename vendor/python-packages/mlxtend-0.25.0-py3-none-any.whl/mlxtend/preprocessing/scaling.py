# Sebastian Raschka 2014-2026
# mlxtend Machine Learning Library Extensions
#
# Classes for column-based scaling of datasets
# Author: Sebastian Raschka <sebastianraschka.com>
#
# License: BSD 3 clause

import numpy as np
import pandas as pd


def minmax_scaling(array, columns, min_val=0, max_val=1):
    """Min max scaling of pandas' DataFrames.

    Parameters
    ----------
    array : pandas DataFrame or NumPy ndarray, shape = [n_rows, n_columns].
    columns : array-like, shape = [n_columns]
        Array-like with column names, e.g., ['col1', 'col2', ...]
        or column indices [0, 2, 4, ...]
    min_val : `int` or `float`, optional (default=`0`)
        minimum value after rescaling.
    max_val : `int` or `float`, optional (default=`1`)
        maximum value after rescaling.

    Notes
    ----------
    If all values in a given column are the same (zero range), the column
    is set to `min_val` rather than silently filled with NaN. This mirrors
    the contract already documented for `standardize` and avoids the
    `RuntimeWarning: invalid value encountered in divide` previously raised
    by the underlying `0 / 0` division.

    Returns
    ----------
    df_new : pandas DataFrame object.
        Copy of the array or DataFrame with rescaled columns.

    Examples
    ----------
    For usage examples, please see
    https://rasbt.github.io/mlxtend/user_guide/preprocessing/minmax_scaling/

    """
    ary_new = array.astype(float)
    if len(ary_new.shape) == 1:
        ary_new = ary_new[:, np.newaxis]

    if isinstance(ary_new, pd.DataFrame):
        ary_newt = ary_new.loc
    elif isinstance(ary_new, np.ndarray):
        ary_newt = ary_new
    else:
        raise AttributeError("Input array must be a pandas" "DataFrame or NumPy array")

    numerator = ary_newt[:, columns] - ary_newt[:, columns].min(axis=0)
    denominator = ary_newt[:, columns].max(axis=0) - ary_newt[:, columns].min(axis=0)
    # Constant columns have zero range; the naive (x - min) / (max - min)
    # would compute 0 / 0 and silently emit NaN with only a numpy
    # RuntimeWarning. Force the denominator to 1 for those columns so the
    # numerator (which is identically zero) collapses the column to 0.0,
    # mirroring the behaviour `standardize` already documents for
    # constant inputs.
    denominator = np.where(denominator == 0, 1, denominator)
    ary_newt[:, columns] = numerator / denominator

    if not min_val == 0 and not max_val == 1:
        ary_newt[:, columns] = ary_newt[:, columns] * (max_val - min_val) + min_val

    return ary_newt[:, columns]


def standardize(array, columns=None, ddof=0, return_params=False, params=None):
    """Standardize columns in pandas DataFrames.

    Parameters
    ----------
    array : pandas DataFrame or NumPy ndarray, shape = [n_rows, n_columns].
    columns : array-like, shape = [n_columns] (default: None)
        Array-like with column names, e.g., ['col1', 'col2', ...]
        or column indices [0, 2, 4, ...]
        If None, standardizes all columns.
    ddof : int (default: 0)
        Delta Degrees of Freedom. The divisor used in calculations
        is N - ddof, where N represents the number of elements.
    return_params : dict (default: False)
        If set to True, a dictionary is returned in addition to the
        standardized array. The parameter dictionary contains the
        column means ('avgs') and standard deviations ('stds') of
        the individual columns.
    params : dict (default: None)
        A dictionary with column means and standard deviations as
        returned by the `standardize` function if `return_params`
        was set to True. If a `params` dictionary is provided, the
        `standardize` function will use these instead of computing
        them from the current array.

    Notes
    ----------
    If all values in a given column are the same, these values are all
    set to `0.0`. The standard deviation in the `parameters` dictionary
    is consequently set to `1.0` to avoid dividing by zero.

    Returns
    ----------
    df_new : pandas DataFrame object.
        Copy of the array or DataFrame with standardized columns.

    Examples
    ----------
    For usage examples, please see
    https://rasbt.github.io/mlxtend/user_guide/preprocessing/standardize/

    """
    ary_new = array.astype(float)
    dim = ary_new.shape
    if len(dim) == 1:
        ary_new = ary_new[:, np.newaxis]

    if isinstance(ary_new, pd.DataFrame):
        ary_newt = ary_new.loc
        if columns is None:
            columns = ary_new.columns
    elif isinstance(ary_new, np.ndarray):
        ary_newt = ary_new
        if columns is None:
            columns = list(range(ary_new.shape[1]))

    else:
        raise AttributeError("Input array must be a pandas " "DataFrame or NumPy array")

    if params is not None:
        parameters = params
    else:
        parameters = {
            "avgs": ary_newt[:, columns].mean(axis=0),
            "stds": ary_newt[:, columns].std(axis=0, ddof=ddof),
        }
    are_constant = np.all(ary_newt[:, columns] == ary_newt[0, columns], axis=0)

    # For constant columns the standard deviation is 0 (or NaN with some ddof
    # values), so dividing by it would propagate NaNs / Infs. Forcing std to
    # 1.0 means the subtraction (col - mean) below collapses the column to
    # exactly 0.0, matching the contract documented in the "Notes" section
    # ("If all values in a given column are the same, these values are all
    # set to 0.0"). The previous version also pre-zeroed the column before
    # the divide, but that turned (0 - mean) / 1 into -mean instead of 0
    # -- see issue #1058.
    for c, b in zip(columns, are_constant):
        if b:
            parameters["stds"][c] = 1.0

    ary_newt[:, columns] = (ary_newt[:, columns] - parameters["avgs"]) / parameters[
        "stds"
    ]

    if return_params:
        return ary_newt[:, columns], parameters
    else:
        return ary_newt[:, columns]
